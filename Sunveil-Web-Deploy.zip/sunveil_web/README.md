# Sunveil Character Lab

Static deployment build of the Sunveil interactive 3D suit-selection prototype.

## Run locally

Use any static web server from this folder, for example:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080/`.

Opening `index.html` directly may work in some browsers, but a local web server is recommended for WebGL/static-host behavior.

## Deploy

This folder is intentionally dependency-free. Upload the contents of this directory to any static host such as GitHub Pages, Netlify, Vercel, Cloudflare Pages, or an equivalent static web host. The entry point is `index.html`.
